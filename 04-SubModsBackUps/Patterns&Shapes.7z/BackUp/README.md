Author: ???

URL: ???

Thanks to everyone who can help me to retrieve original author.

# Generative Design

Funny examples of Processing capabilities

# Truchet

![Truchet](truchet/truchet.png)


# Squares

![Squares](squares/squares.png)


# Moirè

![Moirè](moire/moire.png)
