Author: hiddenenigma

URL: https://github.com/hiddenenigma/365Processing

365 Processing
=============

A self-initiated 365 project that started at the beginning of 2014. The main objective was to learn how to code. 


<i>The Nature of Code</i> by Danielf Shiffman was my primary source for learning along with other supplementary blogs and books. With Shiffman's project, there are so many different ways you can learn–there's a book, website and my favourite, videos. Also, you can acquire all of his code examples through GitHub. 





